# Sample project used by test_extraction.CustomLayoutExtractionTests
from django.utils.translation import ugettext as _

string = _("This is a project-level string")
